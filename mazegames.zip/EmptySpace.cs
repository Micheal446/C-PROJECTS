﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    internal class EmptySpace : Imazeobject
    {
        public char icon { get => ' '; }
        public bool solid { get => false; }
    }
}
