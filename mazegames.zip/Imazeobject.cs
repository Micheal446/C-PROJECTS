﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    public interface  Imazeobject
    {
        char icon { get;  }//shape of maze object

        bool solid {  get;  }//movement block



    }
}
