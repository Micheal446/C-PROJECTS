﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    internal class chrachters : Imazeobject
    {

        public int x {  get; set; }
        public int y { get; set; }
        public char icon{ get => '@';  }
        public bool solid { get => true; }
    }
}
