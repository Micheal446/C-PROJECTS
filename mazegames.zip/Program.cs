﻿namespace $safeprojectname$
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, maze game!");

            Console.WriteLine("use keyboard arrows to move");


            maze maze=new maze(40,20);
            maze.Draw();
            while (true)
            {
            

                maze.move();
            }
        }
    }
}
