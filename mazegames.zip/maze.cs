﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    public class maze
    {
        private int Width;
        private int Height;
        private chrachters chrachters;
        private Imazeobject[,] _object;


        public maze(int width, int height)
        {
            Width = width;
            Height = height;
            _object = new Imazeobject[width, height];
            chrachters = new chrachters()
            {

                x = 1,
                y = 1

            };
        }


        public void Draw()
        {

            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    if (x == Width - 1&& y == Height - 2)
                    {
                        _object[x, y] = new EmptySpace();
                        Console.Write(_object[x, y].icon);
                        if (chrachters.x == x && chrachters.y == y)
                        {
                            Console.WriteLine();

                            Console.WriteLine("$$$$$$  Game over  $$$$$$$$");
                            Environment.Exit(0);
                        }
                    }
                    else if (y == 0 || x == 0 || x == Width - 1 || y == Height - 1)
                    {
                        _object[x, y] = new wall();
                        Console.Write(_object[x, y].icon);
                    }
                    else if (x == chrachters.x && y == chrachters.y)
                    {
                        _object[x, y] = new chrachters();
                        Console.Write(_object[x, y].icon);



                    }
                    else if (x % 3 == 0 && y % 3 == 0)
                    {
                        _object[x, y] = new wall();
                        Console.Write(_object[x, y].icon);



                    }
                    else if (x % 6 == 0 && y % 6 == 0)
                    {
                        _object[x, y] = new wall();
                        Console.Write(_object[x, y].icon);



                    }
                    else
                    {

                        _object[x, y] = new EmptySpace();
                        Console.Write(_object[x, y].icon);


                    }
                }
                Console.WriteLine();
            }

        }

        public void move()
        {

            var input = Console.ReadKey(true);

            var key = input.Key;
            switch (key)
            {

                case ConsoleKey.UpArrow:
                    idpatemove(0, -1);
                    break;
                case ConsoleKey.DownArrow:
                    idpatemove(0, 1);
                    break;
                case ConsoleKey.LeftArrow:
                    idpatemove(-1, 0);

                    break;

                case ConsoleKey.RightArrow:
                    idpatemove(1, 0);

                    break;





            }


        }

        private void idpatemove(int x, int y)
        {

            int nx = chrachters.x + x;

            int ny = chrachters.y + y;

            if (nx < Width && nx >= 0 && ny < Height && ny >= 0)
            {
                if (_object[nx, ny] != null && _object[nx, ny].solid == false)
                {
                    chrachters.x = nx;
                    chrachters.y = ny;
                    Console.Clear();

                    Draw();
                }
            }



        }

    }
}