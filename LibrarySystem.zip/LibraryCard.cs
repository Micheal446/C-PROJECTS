﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    internal class LibraryCard
    {
        public int Number {  get; set; }
    }
}
