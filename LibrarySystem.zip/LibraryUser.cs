﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    internal class LibraryUser:User
    {
        public LibraryUser(string name)
        {
            Name = name;
        }
        public LibraryCard Card {  get; set; }


        public void BorrowBook(Book book, Library l)
        {
            l.BorrowBook(book);

        }


        public void ReturnBook(Book book, Library l)
        {
            l.returnbook(book);
        }

    }
}
