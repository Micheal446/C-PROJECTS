﻿namespace $safeprojectname$
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the library system ");
            
            Console.WriteLine("are you  librarian or regular user(l/r)");
           
            var user =Console.ReadLine().ToUpper()[0];
            var library = Library.GetLibrary();
            Console.Clear();

            if (user == 'L')
            {
                
                Console.WriteLine("enter your name");
                var name=Console.ReadLine();
                Console.Clear();
                Librarian l1 = new Librarian(name);
             
                
                Console.WriteLine($"welcome {l1.Name}");
                Console.Clear();

                while (true)
                {
                    Console.WriteLine("please choose to add book (A), remove book (R), display boos(D)");
                 
                    var choose = Console.ReadLine().ToUpper();
                    Console.Clear();

                    switch (choose)
                    {
                        case "A":
                            Console.WriteLine("Enter book details");
                            var booktitle = Console.ReadLine();
                            var bookAutor = Console.ReadLine();
                            var bookyear = Convert.ToInt32((Console.ReadLine()));
                            Console.Clear();

                            Book book = new Book()
                            {

                                title = booktitle,
                                author = bookAutor,
                                year = bookyear

                            };

                            l1.AddBook(book, library);
                            break;

                        case "R":
                            Console.WriteLine("Enter book details");
                            var booktitles = Console.ReadLine();
                            var bookAutors = Console.ReadLine();
                            var bookyears = Convert.ToInt32((Console.ReadLine()));

                            Book books = new Book()
                            {

                                title = booktitles,
                                author = bookAutors,
                                year = bookyears

                            };

                            l1.AddBook(books, library);
                            break;
                        case "D":
                            Console.WriteLine("all books");
                            l1.DisplayBooks(library);

                            break;

                            default:
                            Environment.Exit(0);
                            break;
                    }
                }

            }
            else if (user == 'R')
            {

                Console.WriteLine("enter your name");
                var name = Console.ReadLine();
                LibraryUser l1 = new LibraryUser(name);

                Console.WriteLine($"welcome user {l1.Name}");
                Console.Clear();

                while (true)
                {
                    Console.WriteLine("please choose to add borrowbook(A),remove (R), display boos(D)");
                    var choose = Console.ReadLine().ToUpper();
                    Console.Clear();

                    switch (choose)
                    {
                        case "A":
                            Console.WriteLine("Enter book details");
                            var booktitle = Console.ReadLine();
                            var bookAutor = Console.ReadLine();
                            var bookyear = Convert.ToInt32((Console.ReadLine()));
                            Console.Clear();

                            Book book = new Book()
                            {

                                title = booktitle,
                                author = bookAutor,
                                year = bookyear

                            };

                            l1.BorrowBook(book, library);
                            break;

                        case "R":
                            Console.WriteLine("Enter book details");
                            var booktitles = Console.ReadLine();
                            var bookAutors = Console.ReadLine();
                            var bookyears = Convert.ToInt32((Console.ReadLine()));
                            Console.Clear();

                            Book books = new Book()
                            {

                                title = booktitles,
                                author = bookAutors,
                                year = bookyears

                            };

                            l1.ReturnBook(books, library);
                            break;
                        case "D":
                            Console.WriteLine("all books");
                            l1.DisplayBroowbook(library);

                            break;

                        default:
                            Environment.Exit(0);
                            break;
                    }
                }


            }
            else
            {
                Console.WriteLine("please enter correct value (l or R)");

            }
        }
    }
}
