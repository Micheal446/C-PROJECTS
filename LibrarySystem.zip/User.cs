﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    internal abstract class User
    {

        public string Name {  get; set; }

        public void DisplayBooks(Library l)
        {

            l.Display();



        }
        

        public void DisplayBroowbook(Library l) {
        
        l.DisplayBroowbook();
        
        }

    }
}
