﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    internal class Library
    {

        private static readonly Library _instance=new Library();

        private Library() { }

        public static Library GetLibrary()
        {
           
            return _instance;
        }
        private Book[] Books = new Book[1000];
        private int countbook = 0;
        private Book[] BorrowedBooks = new Book[100];
        private int countbrrow = 0;

        public void Add(Book Book)
        {
            if (countbook < Books.Length)
            {
                Books[countbook] = Book;
                countbook++;
                Console.WriteLine("Add sccessfully");

            }
            else
            {
                Console.WriteLine("library is full");
            }


        }

        public void Remove(Book Book)
        {
            int index = Array.IndexOf(Books, Book, 0, countbook);
            if (index == -1) return;

            for (int i = index; i < countbook - 1; i++)
            {
                Books[i] = Books[i + 1];
            }
            Books[countbook - 1] = null;
            countbook--;

            Console.WriteLine("remove sccessfully");

        }

        public void Display()
        {

            for (int i = 0; i < countbook; i++)
            {

                Console.WriteLine(Books[i].title);
            }
        }

        public void DisplayBroowbook()
        {

            for (int i = 0; i < countbrrow; i++)
            {

                Console.WriteLine(BorrowedBooks[i].title);
            }
        }

        public void BorrowBook(Book Book)
        {
            if (countbrrow < BorrowedBooks.Length)
            {
                BorrowedBooks[countbrrow] = Book;
                countbrrow++;
                Console.WriteLine("Borrow sccessfully");

            }
            else
            {
                Console.WriteLine("library is full");
            }


        }

        public void returnbook(Book Book)
        {
            int index = Array.IndexOf(BorrowedBooks, Book, 0, countbrrow);
            if (index == -1) return;

            for (int i = index; i < countbrrow - 1; i++)
            {
                BorrowedBooks[i] = BorrowedBooks[i + 1];
            }
            BorrowedBooks[countbrrow - 1] = null;

            countbrrow--;

            Console.WriteLine("remove sccessfully");

        }


    }
}