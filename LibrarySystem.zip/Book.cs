﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    internal class Book
    {
       public string? title { get; set; }
       public string? author {  get; set; }

        public int? year {  get; set; }


    }
}
