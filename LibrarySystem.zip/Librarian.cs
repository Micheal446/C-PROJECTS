﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    internal class Librarian:User
    {
        public int EmpolyeeNumber {  get; set; }
        public Librarian(string name)
        {
            Name = name;
        }
        public void AddBook(Book book,Library l)
        {
            l.Add(book);

        }


        public void RemoveBook(Book book,Library l)
        {
            l.Remove(book);

        }

        
    }
}
