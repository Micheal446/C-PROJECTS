﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    internal class sensor
    {
        public EventHandler<tempArgs> changetemp;
       
        public void settem(int value) {
        
        changetemp.Invoke(this,new tempArgs(value));
        
        }


        public EventHandler<tempArgs> changealarm;

        public void setalarm(int value)
        {

            changetemp.Invoke(this, new tempArgs(value));

        }


    }
}
