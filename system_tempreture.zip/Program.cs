﻿namespace $safeprojectname$
{
    internal class Program
    {
        static void Main(string[] args)
        {
            sensor sensor= new sensor();

            Display display = new Display();
            sensor.changetemp += display.showtem;
            sensor.changealarm += display.showalarm;


            while (true)
            {
                Console.WriteLine("wlcome to my temprture system");

                Console.WriteLine("1- set tempture");

                Console.WriteLine("2- set the alarm value");

                Console.WriteLine("3-Exit");
                 
               var r= Console.ReadLine();
                switch (r)
                {
                    case "1":
                        var t= Console.ReadLine();
                        int v=Convert.ToInt32(t);
                        sensor.settem(v);
                        break; 
                    case "2":
                        var A = Console.ReadLine();
                        int o = Convert.ToInt32(A);
                        sensor.setalarm(o);
                        break;
                    case "3":
                        return;
                        break;
                    default: 
                        Console.WriteLine("valid input");
                        break;
                }


            }


        }
    }
}
