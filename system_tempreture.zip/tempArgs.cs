﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    internal class tempArgs:EventArgs
    {
        public int tempe { get; set; }

        public tempArgs(int ntemp)
        {
            tempe = ntemp;
        }


        public int alarm { get; set; }

        public void alarmargs(int ntemp)
        {
            tempe = ntemp;
        }


    }
}
