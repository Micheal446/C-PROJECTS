﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    internal class Display
    {
        public void showtem(object o,tempArgs args)
        {
            Console.WriteLine($"temperture = {args.tempe}");


        }


        public void showalarm(object o, tempArgs args)
        {
            Console.WriteLine($"alarm = {args.alarm}");


        }



    }
}
