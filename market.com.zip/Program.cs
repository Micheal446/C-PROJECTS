﻿using System.ComponentModel;

namespace $safeprojectname$
{
    internal class Program
    {
        static public List<string> caritem=new List<string>();
        static public Dictionary<string,double>iteamprice=new Dictionary<string, double>()
        {
            {"camer",88.99 },
            {"TV",900.99 },

            {"radio",10000 }


        };

        static   Stack<string> stack=new Stack<string>();
        static void Main(string[] args)
        {while(true) {
                Console.WriteLine("welcome to my shop");

                Console.WriteLine(" ==========================");


                Console.WriteLine("1=add item to cart");
            Console.WriteLine("2=view item carts");
            Console.WriteLine("3=remove item from cart");
            Console.WriteLine("4=cheackout");
            Console.WriteLine("5=undo last action");
            Console.WriteLine("6=exit");
            
            Console.WriteLine("enter choose number");

            var number=Console.ReadLine();
            int n=Convert.ToInt32(number);
            Console.Clear();
                switch (n)
                {
                    case (1):
                        Addingnew();
                        break;


                    case (2):
                        viewitem();
                        break;
                    case (3):
                        remove();
                        break;
                    case (4):
                        cheakout();
                        break;

                    case (5):
                        undoitem();
                        break;
                    case (6):
                        Environment.Exit(0);
                        break;



                    default:

                        Console.WriteLine("invalid code");



                        break;




                }
            }


        }  

        
        private static void undoitem()
        {
            if (stack.Count > 0)
            {
                string lastaction = stack.Pop();
                Console.WriteLine($"last action you do {lastaction}");
                var array = lastaction.Split();
                if (lastaction.Contains("add"))
                {
                    caritem.Remove(array[1]);

                }else if (lastaction.Contains("remove"))
                {
                    caritem.Add(array[1]);

                }
                else
                {
                    Console.WriteLine("valid error");
                }
            
            }
        }

        private static void remove()
        {

            viewitem();
            if (caritem.Any())
            {
                Console.WriteLine("please select iteam to remove");
                string iteamremove = Console.ReadLine();

                if (iteamremove != null && caritem.Contains(iteamremove))
                {
                
                    caritem.Remove(iteamremove);
                    stack.Push($"iteam {iteamremove} to remove");
                    
                    Console.WriteLine("remove succesed");
                }
                else
                {

                    Console.WriteLine("valid");
                }

            }
            else
            {
                Console.WriteLine("valid");
            }
        }

        private static void cheakout()
        {
            
            if (caritem.Any())
            {
                
                double total = 0;
                var iteams = getpriceitam();

                foreach (var team in iteams) {

                    total += team.Item2;
                
                
                }
                Console.WriteLine($"total price = {total}");
                caritem.Clear();
                stack.Push("cheachout");
            }
            else
            {

                Console.WriteLine("valid");
            }
        
        }

        private static void viewitem()
        {
            var cars = getpriceitam();

            if (cars.Any())
            {
                foreach (var itam in cars )
                {
                    Console.WriteLine($"iteam : {itam.Item1}  ==  price : {itam.Item2}");
                }
            }
        }

        private static IEnumerable<Tuple<string, double>> getpriceitam()
        {
           var itamprice = new List<Tuple<string,double>>();
            foreach(var itam in caritem)
            {
                double price = 0;
                bool b= iteamprice.TryGetValue(itam, out price);
                if (b)
                {
                    Tuple<string,double> it=new Tuple<string,double>(itam,price);
                    itamprice.Add(it);

                }
            }
            return itamprice;

        }
        private static void Addingnew()
        {
            Console.WriteLine("avalibale items");
            foreach(var itam in iteamprice)
            {
                Console.WriteLine($"iteam : {itam.Key} __ price : {itam.Value}");


            }
            Console.WriteLine("enter  iteam :");
            var item=Console.ReadLine();
            if(item==null && iteamprice.ContainsKey(item))
            {
               caritem.Add(item);
                stack.Push($"iteam {item} add iteam");
                Console.WriteLine("succes add");
            }
            else
            {
                Console.WriteLine("valid itam");

            }


        }
    }
}
